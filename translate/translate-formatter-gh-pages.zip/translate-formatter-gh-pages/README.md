# translate-formatter
A tool to make translating and formatting the description of the SDS easier.

http://scratchdesignstudio.github.io/translate-formatter
